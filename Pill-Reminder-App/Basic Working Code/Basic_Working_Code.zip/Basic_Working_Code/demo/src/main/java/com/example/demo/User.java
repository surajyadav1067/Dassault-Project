package com.example.demo;

public class User {
    String Username;
    Integer Userage;
    String Useremail;
    Long Number;

    public User(String Username, int Userage, String Useremail, Long Number) {
        this.Username = Username;
        this.Userage = Userage;
        this.Useremail = Useremail;
        this.Number = Number;
    }

    public String getName() {
        return this.Username;
    }

    public int getAge() {
        return this.Userage;
    }

    public String getEmail() {
        return this.Useremail;
    }

    public Long getNumber() {
        return this.Number;
    }

}
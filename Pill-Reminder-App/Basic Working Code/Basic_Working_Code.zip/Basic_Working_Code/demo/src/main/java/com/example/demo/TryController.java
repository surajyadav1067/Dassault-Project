package com.example.demo;

import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.ArrayList;

@RestController
public class TryController {

    @RequestMapping("/display")
    @ResponseBody
    public String display() {
        return ("Harshil" + " Bhatt");
    }

    //@CrossOrigin(origins = "http://localhost:8090")
    @CrossOrigin(origins = "*")
    @RequestMapping("/show")
    @ResponseBody
    public ArrayList<User> show() {

        String connectionUrl = "jdbc:sqlserver://HP-AU624TX\\SQLEXPRESS;DatabaseName=Dassault_DB;integratedSecurity=true";
        ArrayList<User> u1 = new ArrayList<User>();
        try (Connection con = DriverManager.getConnection(connectionUrl); Statement stmt = con.createStatement()) {
            String SQL = "SELECT * FROM UserTable;";
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                u1.add(new User(rs.getString("Username"), rs.getInt("Userage"), rs.getString("Useremail"), rs.getLong("Number")));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return u1;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/add")
    @ResponseBody
    public void add(@RequestBody User uitem) {
        String connectionUrl = "jdbc:sqlserver://HP-AU624TX\\SQLEXPRESS;DatabaseName=Dassault_DB;integratedSecurity=true";

        try (Connection con = DriverManager.getConnection(connectionUrl); Statement stmt = con.createStatement()) {

            String SQL = "insert into person values ('" + uitem.getName() + "'," + uitem.getAge() + ")";
            stmt.executeUpdate(SQL);

        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

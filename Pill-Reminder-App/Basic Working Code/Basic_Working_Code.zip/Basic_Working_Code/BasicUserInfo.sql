CREATE TABLE UserTable
(
Username VARCHAR(20),
Userage INT,
Useremail VARCHAR(30),
Number BIGINT
);

INSERT INTO UserTable VALUES
('Amit', 25, 'amit@email.com', 9876543210);

INSERT INTO UserTable VALUES
('Binod', 23, 'binod@email.com', 9988776655);

INSERT INTO UserTable VALUES
('Cameroon', 27);


INSERT INTO UserTable VALUES
('Disha', 20);

DROP TABLE UserTable;

SELECT * FROM UserTable;